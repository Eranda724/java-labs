import java.util.Scanner;
import java.util.Arrays;

public class HammingCode
{
	public static int[]sender_message_convert(int []sender_message_array)
	{
		int total=0;
		for(int i=0;i<3;++i)
		{
			int paritybit_position=(int)Math.pow(2,i)-1;
			if(i==0)
			{
				total=sender_message_array[2]+sender_message_array[4]+sender_message_array[6]+sender_message_array[8]+sender_message_array[10];
				if(total%2==0)
				{
					sender_message_array[paritybit_position]=0;
				}
				else
				{
					sender_message_array[paritybit_position]=1;
				}
			}
			else if(i==1)	
			{
				total=0;
				total=sender_message_array[2]+sender_message_array[5]+sender_message_array[6]+sender_message_array[9]+sender_message_array[10];
				if(total%2==0)
				{
					sender_message_array[paritybit_position]=0;
				}
				else
				{
					sender_message_array[paritybit_position]=1;
				}	
			}
			else if(i==2)	
			{
				total=0;
				total=sender_message_array[4]+sender_message_array[5]+sender_message_array[6]+sender_message_array[11];
				if(total%2==0)
				{
					sender_message_array[paritybit_position]=0;
				}
				else
				{
					sender_message_array[paritybit_position]=1;
				}	
			}
			else
			{
				total=0;
				total=sender_message_array[8]+sender_message_array[9]+sender_message_array[10]+sender_message_array[11];
				if(total%2==0)
				{
					sender_message_array[paritybit_position]=0;
				}
				else
				{
					sender_message_array[paritybit_position]=1;
				}
			}
		}
		return 	sender_message_array;
	}	

	public static boolean statement(int []reciver_message_word)
	{
		int total=0,increment=0;
		for(int i=0;i<=3;++i)
		{
			int paritybit_position=(int)Math.pow(2,i)-1;
			if(i==0)
			{
				total=reciver_message_word[2]+reciver_message_word[4]+reciver_message_word[6]+reciver_message_word[8]+reciver_message_word[10];
				if(total%2==0)
				{
					if(reciver_message_word[paritybit_position]==0)
					{
						++increment;
					}
				}
				else
				{
					if(reciver_message_word[paritybit_position]==1)
					{
						++increment;
					}
				}
			}
			else if(i==1)	
			{
				total=0;
				total=reciver_message_word[2]+reciver_message_word[5]+reciver_message_word[6]+reciver_message_word[9]+reciver_message_word[10];
				if(total%2==0)
				{
					if(reciver_message_word[paritybit_position]==0)
					{
						++increment;
					}
				}
				else
				{
					if(reciver_message_word[paritybit_position]==1)
					{
						++increment;
					}
				}		
			}
			else if(i==2)	
			{
				total=0;
				total=reciver_message_word[4]+reciver_message_word[5]+reciver_message_word[6]+reciver_message_word[11];
				if(total%2==0)
				{
					if(reciver_message_word[paritybit_position]==0)
					{
						++increment;
					}
				}
				else
				{
					if(reciver_message_word[paritybit_position]==0)
					{
						++increment;
					}
				}	
			}
			else
			{
				total=0;
				total=reciver_message_word[8]+reciver_message_word[9]+reciver_message_word[10]+reciver_message_word[11];
				if(total%2==0)
				{
					if(reciver_message_word[paritybit_position]==0)
					{
						++increment;
					}
				}
				else
				{
					if(reciver_message_word[paritybit_position]==1)
					{
						++increment;
					}
				}
			}
		}
		if(increment==3)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public static void correct(int [] reciver_message_array)
	{
		int total=0,correct_parity_bit=0;
		for(int i=0;i<=3;++i)
		{
			int paritybit_position=(int)Math.pow(2,i)-1;
			if(i==0)
			{
				total=reciver_message_array[2]+reciver_message_array[4]+reciver_message_array[6]+reciver_message_array[8]+reciver_message_array[10];
				if(total%2==0)
				{
					if(reciver_message_array[paritybit_position]!=0)
					{
						correct_parity_bit+=paritybit_position;
					}
				}
				else
				{
					if(reciver_message_array[paritybit_position]!=1)
					{
						correct_parity_bit+=paritybit_position;
					}
				}
			}
			else if(i==1)	
			{
				total=0;
				total=reciver_message_array[2]+reciver_message_array[5]+reciver_message_array[6]+reciver_message_array[9]+reciver_message_array[10];
				if(total%2==0)
				{
					if(reciver_message_array[paritybit_position]!=0)
					{
						correct_parity_bit+=paritybit_position;
					}
				}
				else
				{
					if(reciver_message_array[paritybit_position]!=1)
					{
						correct_parity_bit+=paritybit_position;
					}
				}		
			}
			else if(i==2)	
			{
				total=0;
				total=reciver_message_array[4]+reciver_message_array[5]+reciver_message_array[6]+reciver_message_array[11];
				if(total%2==0)
				{
					if(reciver_message_array[paritybit_position]!=0)
					{
						correct_parity_bit+=paritybit_position;
					}
				}
				else
				{
					if(reciver_message_array[paritybit_position]!=1)
					{
						correct_parity_bit+=paritybit_position;
					}
				}	
			}
			else
			{
				total=0;
				total=reciver_message_array[8]+reciver_message_array[9]+reciver_message_array[10]+reciver_message_array[11];
				if(total%2==0)
				{
					if(reciver_message_array[paritybit_position]!=0)
					{
						correct_parity_bit+=paritybit_position;
					}
				}
				else
				{
					if(reciver_message_array[paritybit_position]!=1)
					{
						correct_parity_bit+=paritybit_position;
					}
				}
			}
		}
		System.out.println((correct_parity_bit+2) +" bit position is wrong ");
		System.out.print("After the correction of correct message is : ");
		if(reciver_message_array[correct_parity_bit+1]==0)
		{
			reciver_message_array[correct_parity_bit+1]=1;
		}
		else if(reciver_message_array[correct_parity_bit+1]==1)
		{
			reciver_message_array[correct_parity_bit+1]=0;
		}
		for(int i=0;i<reciver_message_array.length;++i)
		{
			System.out.print(reciver_message_array[i]);
		}
	}
		
	public static void main(String args[])
	{
		int [] sender_message_array=new int[12];
		Arrays.fill(sender_message_array,0);
		System.out.print("Enter the sender message(for 8 bits only 0 or 1 s) : ");
		Scanner Sender_message=new Scanner(System.in);
		String sender_message=Sender_message.nextLine();
		int j=0;
		for(int i=0;i<sender_message_array.length;++i)
		{
			if((i!=0)&&(i!=1)&&(i!=3)&&(i!=7))
			{
				if(sender_message.charAt(j)=='0')
				{
					sender_message_array[i]=0;
					++j;
				}
				else
				{
					sender_message_array[i]=1;
					++j;
				}
				if(j==sender_message.length())
				{
					break;
				}
			}
		}
		
		int sender_message_word[]=sender_message_convert(sender_message_array);
		System.out.print("Code word : ");
		for(int i=0;i<sender_message_word.length;++i)
		{
			System.out.print(sender_message_word[i]);
		}
		
		System.out.print("\nEnter the reciver message(for 12 bits only 0 or 1 s) : ");
		Scanner Reciver_message=new Scanner(System.in);
		String reciver_message=Reciver_message.nextLine();
		int []reciver_message_array=new int[reciver_message.length()];
		for(int i=0;i<reciver_message.length();++i)
		{
			if(reciver_message.charAt(i)=='0')
			{
				reciver_message_array[i]=0;
			}
			else
			{
				reciver_message_array[i]=1;
			}
		}
		if(statement(reciver_message_array))
		{
			System.out.println("Message send no error" );
		}
		else
		{
			System.out.println("Message currepted" );
			correct(reciver_message_array);
		}				
	}
}
		