import java.util.Scanner;
 
public class CRC {
 
    // Define polynomial
    final static String polynomial = "1010000001010110";
 
    // Perform XOR division
    public static int[] xordivider(int[] numerator, int[] denominator) {
        int[] remainder = new int[denominator.length - 1];
        System.arraycopy(numerator, 0, remainder, 0, denominator.length - 1);
 
        for (int i = denominator.length - 1; i < numerator.length; i++) {
            if (remainder[0] == 1) {
                for (int j = 1; j < denominator.length - 1; j++) {
                    remainder[j - 1] = remainder[j] ^ denominator[j];
                }
                remainder[denominator.length - 2] = numerator[i] ^ denominator[denominator.length - 1];
            } else {
                for (int j = 1; j < denominator.length - 1; j++) {
                    remainder[j - 1] = remainder[j];
                }
                remainder[denominator.length - 2] = numerator[i];
            }
        }
        return remainder;
    }
 
    public static void main(String[] args) {
        // Get user input for sender message
        System.out.print("Enter the send message (1 or 0 s): ");
Scanner sendMessageScanner = new Scanner(System.in);
        String sendMessage = sendMessageScanner.nextLine();
        int[] sendMessageArray = new int[sendMessage.length() + polynomial.length() - 1];
 
        // Convert sender message to array
        for (int i = 0; i < sendMessageArray.length; ++i) {
            if (i < sendMessage.length()) {
                sendMessageArray[i] = (sendMessage.charAt(i) == '1') ? 1 : 0;
            } else {
                sendMessageArray[i] = 0;
            }
        }
 
        // Convert polynomial to array
        int[] polynomialArray = new int[polynomial.length()];
        for (int i = 0; i < polynomial.length(); ++i) {
            polynomialArray[i] = (polynomial.charAt(i) == '1') ? 1 : 0;
        }
 
        // Calculate remainder using sender message and polynomial
        int[] remainder1 = xordivider(sendMessageArray, polynomialArray);
 
        // Get user input for received message
        System.out.print("Enter the received message (1 or 0 s): ");
Scanner receiveMessageScanner = new Scanner(System.in);
        String receiveMessage = receiveMessageScanner.nextLine();
        int[] receiveMessageArray = new int[receiveMessage.length() + remainder1.length];
 
        // Convert received message to array
        for (int i = 0; i < receiveMessageArray.length; ++i) {
            if (i < receiveMessage.length()) {
                receiveMessageArray[i] = (receiveMessage.charAt(i) == '1') ? 1 : 0;
            } else {
                receiveMessageArray[i] = remainder1[i - receiveMessage.length()];
            }
        }
 
        // Calculate remainder using received message and polynomial
        int[] remainder2 = xordivider(receiveMessageArray, polynomialArray);
 
        // Check if the remainder has only zeros
        int total = 0;
        for (int i = 0; i < remainder2.length; ++i) {
            total += remainder2[i];
        }
 
        // Print result based on the remainder
        if (total == 0) {
            System.out.println("Message arrived with no error");
        } else {
            System.out.println("Message corrupted");
        }
    }
}