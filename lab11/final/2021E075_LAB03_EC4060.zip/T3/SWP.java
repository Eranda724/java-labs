import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;

public class SWP
{
	// ACK - acknowlage
	public static void main(String args[])
	{
		System.out.print("Enter the number of frame you expect : "); //get a user input number of frame
		Scanner No_frame=new Scanner(System.in);
		int no_frame=No_frame.nextInt();
		
		Queue <Integer> frame_queue = new LinkedList <>();  //define as queue for the frame
		for(int i=0;i<no_frame;++i)
		{
			frame_queue.offer(i);
		}
		
		System.out.print("Enter the size of window : "); //get a user input size of window
		Scanner Windows_size=new Scanner(System.in);
		int windows_size=Windows_size.nextInt();

		int increment1=0;   //define increment
		for(;increment1<windows_size;++increment1)
		{
			System.out.println("Sending frame "+increment1 );
		}
		
		int increment2=0;
		while(!frame_queue.isEmpty()) //check whether all the frame are send or not
		{
			System.out.print("Enter the acknowlage number of reciver : "); //get a user input which Ack is recived
			Scanner Acknowlage=new Scanner(System.in);
			int acknowlage=Acknowlage.nextInt();
			if(acknowlage==increment2)   //check whether correct acknowlage are recived
			{
				frame_queue.poll();
				if(increment1<no_frame)
				{
					System.out.println("Sending frame "+increment1 );
				}
				++increment1;
				++increment2;
				continue;
			}
			else
			{
				int increment3=increment2; //if correct ACK not recive the agian previous frame send
				for(int i=0;i<windows_size;++i)
				{
					System.out.println("Sending frame " + (increment3) );
					++increment3;
				}
			}	
		}
		if(frame_queue.isEmpty()) //after the all frame send and all ACK recive then dispaly above message
		{
			System.out.println("All the frams are transmited and all the ACK recived " );
		}
	}
}
			
			
				
		